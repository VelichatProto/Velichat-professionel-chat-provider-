package com.velichat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF09151D)
private val Panel = Color(0xFF142630)
private val Panel2 = Color(0xFF1B3440)
private val Mint = Color(0xFF29D3AE)
private val Muted = Color(0xFF9BB0BA)

private data class Chat(val username: String, val preview: String, val time: String)
private data class Message(val text: String, val mine: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VeliChatApp() }
    }
}

@Composable
private fun VeliChatApp() {
    var screen by remember { mutableStateOf("login") }
    var registering by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var selectedChat by remember { mutableStateOf("VeliChat Destek") }
    var draft by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Bu sürüm arayüz demosudur; henüz sunucuya bağlanmaz.") }
    var readReceipts by remember { mutableStateOf(true) }
    var onlineStatus by remember { mutableStateOf(false) }
    var lastSeen by remember { mutableStateOf(false) }
    var typingStatus by remember { mutableStateOf(false) }
    var blockDuration by remember { mutableStateOf("1 gün") }
    var showBlockMenu by remember { mutableStateOf(false) }
    var blockedUser by remember { mutableStateOf("Henüz engellenen yok") }
    var chats by remember { mutableStateOf(listOf(
        Chat("VeliChat Destek", "VeliChat'e hoş geldin!", "Şimdi"),
        Chat("Ahmet_35", "Merhaba, nasılsın?", "14:32"),
        Chat("Mehmet_07", "Fotoğraf gönderdi", "13:15")
    )) }
    var messages by remember { mutableStateOf(listOf(
        Message("VeliChat demo sohbetine hoş geldin.", false),
        Message("Burada mesaj ekranını deneyebilirsin.", false)
    )) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Mint,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            when (screen) {
                "login" -> LoginScreen(
                    username, { username = it }, password, { password = it },
                    registering, { registering = it }, status,
                    onContinue = {
                        if (username.isBlank() || password.length < 6) {
                            status = "Kullanıcı adı ve en az 6 karakterli şifre gir."
                        } else {
                            screen = "chats"
                            status = "Demo oturumu açıldı. Gerçek hesap oluşturulmadı."
                        }
                    }
                )
                "chats" -> ChatListScreen(
                    chats, search, { search = it },
                    onOpen = { selectedChat = it; messages = listOf(
                        Message("$it ile demo sohbeti açıldı.", false)
                    ); screen = "chat" },
                    onSearch = { screen = "search" },
                    onSettings = { screen = "settings" }
                )
                "chat" -> ChatScreen(
                    selectedChat, messages, draft, { draft = it },
                    onSend = {
                        if (draft.isNotBlank()) {
                            messages = messages + Message(draft.trim(), true)
                            draft = ""
                        }
                    },
                    onBack = { screen = "chats" },
                    onProfile = { screen = "block" }
                )
                "search" -> SearchScreen(search, { search = it }, onBack = { screen = "chats" },
                    onOpen = { selectedChat = it; messages = listOf(Message("Bu sohbet demo amaçlıdır.", false)); screen = "chat" })
                "settings" -> SettingsScreen(
                    readReceipts, { readReceipts = it },
                    onlineStatus, { onlineStatus = it },
                    lastSeen, { lastSeen = it },
                    typingStatus, { typingStatus = it },
                    blockedUser, onBlocked = { screen = "block" },
                    onBack = { screen = "chats" }
                )
                "block" -> BlockScreen(
                    selectedChat, blockDuration, { blockDuration = it },
                    showBlockMenu, { showBlockMenu = it },
                    blockedUser, onBlock = { blockedUser = "$selectedChat — $blockDuration"; screen = "settings" },
                    onUnblock = { blockedUser = "Henüz engellenen yok" },
                    onBack = { screen = "chat" }
                )
            }
        }
    }
}

@Composable
private fun LoginScreen(
    username: String, onUsername: (String) -> Unit,
    password: String, onPassword: (String) -> Unit,
    registering: Boolean, onRegistering: (Boolean) -> Unit,
    status: String, onContinue: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().background(Ink).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Logo()
        Spacer(Modifier.height(14.dp))
        Text("VeliChat", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("Özgürce konuş. Güvenle paylaş.", color = Muted)
        Spacer(Modifier.height(28.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(if (registering) "Yeni hesap oluştur" else "Hoş geldin", fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(username, onUsername, label = { Text("Kullanıcı adı") }, singleLine = true)
                OutlinedTextField(password, onPassword, label = { Text("Şifre (en az 6 karakter)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                Button(onClick = onContinue, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                    Text(if (registering) "Demo kaydı" else "Demo giriş", color = Ink, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = { onRegistering(!registering) }, Modifier.align(Alignment.CenterHorizontally)) {
                    Text(if (registering) "Zaten hesabım var" else "Hesap oluştur", color = Mint)
                }
                Text(status, color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Telefon numarası gerekmez • Yerel arayüz demosu", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun Logo() {
    Box(Modifier.size(70.dp).background(Mint, RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
        Text("V", color = Ink, fontSize = 40.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun ChatListScreen(
    chats: List<Chat>, search: String, onSearch: (String) -> Unit,
    onOpen: (String) -> Unit, onSearchPage: () -> Unit, onSettings: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("VeliChat", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Sohbetlerin", color = Muted, fontSize = 13.sp)
            }
            TextButton(onClick = onSettings) { Text("Ayarlar", color = Mint) }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(search, onSearch, Modifier.fillMaxWidth(), placeholder = { Text("Sohbetlerde ara") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onSearchPage, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel2)) {
            Text("＋  Kullanıcı adıyla yeni sohbet", color = Mint)
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chats.filter { it.username.contains(search, true) || it.preview.contains(search, true) }) { chat ->
                Row(
                    Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable { onOpen(chat.username) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(chat.username)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(chat.username, fontWeight = FontWeight.SemiBold)
                        Text(chat.preview, color = Muted, fontSize = 13.sp)
                    }
                    Text(chat.time, color = Muted, fontSize = 11.sp)
                }
            }
        }
        DemoNotice()
    }
}

@Composable
private fun SearchScreen(query: String, onQuery: (String) -> Unit, onBack: () -> Unit, onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Header("Kullanıcı bul", onBack)
        OutlinedTextField(query, onQuery, Modifier.fillMaxWidth(), label = { Text("Kullanıcı adı") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        Text("Gerçek kullanıcı araması için sunucu bağlantısı henüz eklenmedi.", color = Muted, fontSize = 13.sp)
        if (query.isNotBlank()) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp).background(Panel, RoundedCornerShape(14.dp)).clickable { onOpen(query) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(query)
                Text(query, Modifier.weight(1f).padding(start = 10.dp))
                Text("Demo sohbet aç", color = Mint, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ChatScreen(
    title: String, messages: List<Message>, draft: String, onDraft: (String) -> Unit,
    onSend: () -> Unit, onBack: () -> Unit, onProfile: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("‹", Modifier.clickable { onBack() }.padding(8.dp), color = Mint, fontSize = 30.sp)
            Avatar(title)
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text("Durum bilgisi gizli", color = Muted, fontSize = 11.sp)
            }
            TextButton(onClick = onProfile) { Text("⋮", color = Mint, fontSize = 22.sp) }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                    Box(Modifier.widthIn(max = 290.dp).background(if (msg.mine) Color(0xFF155C50) else Panel2, RoundedCornerShape(16.dp)).padding(12.dp)) {
                        Text(msg.text)
                    }
                }
            }
        }
        DemoNotice()
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(draft, onDraft, Modifier.weight(1f), placeholder = { Text("Mesaj yaz…") }, maxLines = 4)
            Spacer(Modifier.width(8.dp))
            Button(onClick = onSend, colors = ButtonDefaults.buttonColors(containerColor = Mint)) { Text("➤", color = Ink) }
        }
    }
}

@Composable
private fun SettingsScreen(
    read: Boolean, onRead: (Boolean) -> Unit,
    online: Boolean, onOnline: (Boolean) -> Unit,
    last: Boolean, onLast: (Boolean) -> Unit,
    typing: Boolean, onTyping: (Boolean) -> Unit,
    blocked: String, onBlocked: () -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Header("Gizlilik ve ayarlar", onBack)
        Text("GİZLİLİK", color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        SettingSwitch("Okundu bilgisi", "Mesajın okununca karşı tarafa bildir.", read, onRead)
        SettingSwitch("Çevrimiçi bilgisi", "Çevrimiçi durumunu göster.", online, onOnline)
        SettingSwitch("Son görülme", "Son aktif olduğun zamanı göster.", last, onLast)
        SettingSwitch("Yazıyor göstergesi", "Mesaj yazarken göster.", typing, onTyping)
        Spacer(Modifier.height(18.dp))
        Text("ENGELLEME", color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Engellenen kişiler")
                Text(blocked, color = Muted, fontSize = 12.sp)
            }
            TextButton(onClick = onBlocked) { Text("Yönet", color = Mint) }
        }
        DemoNotice()
    }
}

@Composable
private fun SettingSwitch(title: String, description: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(description, color = Muted, fontSize = 12.sp)
        }
        Switch(checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun BlockScreen(
    username: String, duration: String, onDuration: (String) -> Unit,
    expanded: Boolean, onExpanded: (Boolean) -> Unit,
    blocked: String, onBlock: () -> Unit, onUnblock: () -> Unit, onBack: () -> Unit
) {
    val durations = listOf("5 dakika", "1 saat", "1 gün", "3 gün", "5 gün", "7 gün", "15 gün", "1 ay", "Süresiz")
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Header("Gizli engelleme", onBack)
        Text(username, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Engellenen kişiye bildirim gönderilmez.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        Text("Engelleme süresi")
        Box {
            OutlinedButton(onClick = { onExpanded(true) }) { Text(duration, color = Color.White) }
            DropdownMenu(expanded, onDismissRequest = { onExpanded(false) }) {
                durations.forEach { item ->
                    DropdownMenuItem(text = { Text(item) }, onClick = { onDuration(item); onExpanded(false) })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onBlock, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
            Text("Bu kişiyi engelle (demo)", color = Ink)
        }
        Spacer(Modifier.height(22.dp))
        Text("Mevcut engel: $blocked", color = Muted, fontSize = 13.sp)
        OutlinedButton(onClick = onUnblock, Modifier.fillMaxWidth()) { Text("Engeli kaldır (demo)") }
        DemoNotice()
    }
}

@Composable
private fun Header(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 18.dp)) {
        Text("‹", Modifier.clickable { onBack() }.padding(end = 14.dp), color = Mint, fontSize = 30.sp)
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Avatar(name: String) {
    Box(Modifier.size(46.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) {
        Text(name.take(1).uppercase(), color = Mint, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
private fun DemoNotice() {
    Text("ÖN İZLEME • Mesajlar ve ayarlar yalnızca bu ekranda geçici tutulur; sunucuya kaydedilmez.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(vertical = 10.dp))
}
