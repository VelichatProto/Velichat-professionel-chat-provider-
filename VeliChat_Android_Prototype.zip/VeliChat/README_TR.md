# VeliChat — Android arayüz prototipi

Bu sürüm, VeliChat'in koyu temalı ve etkileşimli Android arayüz prototipidir. Giriş/kayıt ekranı, sohbet listesi, örnek sohbet, kullanıcı adı arama ekranı, gizlilik anahtarları ve süreli engelleme ekranı bulunur.

## Önemli: Bu henüz gerçek mesajlaşma uygulaması değildir
- Giriş ve kayıt yalnızca yerel demo akışıdır; hesap oluşturulmaz.
- Mesajlar ve ayarlar uygulama belleğinde geçici tutulur; uygulama kapanınca kaybolur.
- Kullanıcı adı arama sunucuya bağlanmaz.
- Fotoğraf/video/ses aktarımı, uçtan uca şifreleme, sesli/görüntülü arama ve WhatsApp entegrasyonu henüz yoktur.
- Gizlilik anahtarları şimdilik arayüz prototipidir; sunucu davranışını değiştirmez.

## Android'i açma
1. Klasörü Android Studio ile aç.
2. JDK 17 ve Android SDK 35 kurulu olsun.
3. Gradle senkronizasyonunu tamamla.
4. `app` yapılandırmasını bir Android telefonda çalıştır.
5. APK için Build > Build Bundle(s) / APK(s) > Build APK(s).

Bu arşivde Gradle Wrapper bulunmaz; Android Studio'nun kurulu Gradle/Android araçlarını kullan.

## Sonraki geliştirme aşamaları
1. Matrix Synapse sunucusunu doğru yapılandırma ve HTTPS.
2. Android Matrix SDK ile gerçek kayıt/giriş, kullanıcı arama, oda ve mesajlar.
3. Güvenilir SDK üzerinden uçtan uca şifreleme ve anahtar kurtarma.
4. Medya yükleme, push bildirimleri, engelleme ve sunucu tarafı gizlilik tercihleri.
5. WebRTC/MatrixRTC, TURN ve arama testleri.
6. Güvenlik, kötüye kullanım önleme ve imzalı sürüm.

## Güvenlik
Bu prototipi gerçek özel konuşmalar için kullanmayın. Üretime çıkmadan önce kimlik doğrulama, şifreleme, erişim kontrolleri, veri saklama ve güvenlik testleri tamamlanmalıdır.
